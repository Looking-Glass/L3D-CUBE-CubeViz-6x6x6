//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DfuTool.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDM_INSTALLLIBUSBHELP           101
#define IDD_DFUTOOL_DIALOG              102
#define IDM_DFUHELP                     102
#define IDR_MAINFRAME                   128
#define IDB_LAMPRED                     129
#define IDB_LAMPGREEN                   130
#define IDB_LAMPGRAY                    131
#define IDB_LAMPGRAY24                  132
#define IDB_LAMPGREEN24                 133
#define IDB_LAMPRED24                   134
#define IDB_LAMPGREEN16                 135
#define IDB_LAMPRED16                   136
#define IDB_LAMPYELLOW16                137
#define IDB_LAMPYELLOW24                138
#define IDB_LAMPBLUE24                  139
#define IDD_HELP_VIEW                   140
#define IDD_DFUTOOL_DIALOG_ONEKEY       141
#define IDD_DFUHELP_VIEW                142
#define IDB_BITMAP_UNKNOW               150
#define IDB_PNG1                        151
#define IDB_PNG_BK                      151
#define IDD_DIALOG1                     152
#define IDD_WAITING_DLG                 152
#define IDR_MENU1                       153
#define IDR_POPUPMENU1                  153
#define IDC_STATIC_NOTE                 1000
#define IDC_STATIC_TITLE                1001
#define IDC_BTN_INSTALLLIBUSBK          1002
#define IDC_STATIC_NOTE2                1003
#define IDC_BTN_BROWSE1                 1011
#define IDC_BTN_BROWSE2                 1012
#define IDC_BTN_BROWSE3                 1013
#define IDC_BTN_DOWNLOAD1               1021
#define IDC_BTN_DOWNLOAD2               1022
#define IDC_BTN_DOWNLOAD3               1023
#define IDC_EDIT_PROMPT                 1027
#define IDC_STATIC_WEBSOURCE            1028
#define IDC_STATIC_WORKINFO             1029
#define IDC_BTN_AUTO                    1030
#define IDC_BTN_UPDATE1                 1031
#define IDC_BTN_UPDATE2                 1032
#define IDC_BTN_UPDATE3                 1033
#define IDC_BTN_FIXCUBE                 1034
#define IDC_STATIC_CURPART              1035
#define IDC_STATIC_CURFILE              1035
#define IDC_COMBO_DEVLIST               1036
#define IDC_BTN_LISTALL                 1037
#define IDC_BTN_INSTALL                 1038
#define IDC_COMBO_COMM                  1039
#define IDC_BTN_TODFUMODE               1040
#define IDC_EDIT1                       1041
#define IDC_BTN_INSTALL2                1041
#define IDC_BTN_INSTALLDFU              1041
#define IDC_EDIT2                       1042
#define IDC_EDIT3                       1043
#define IDC_SYSLINK1                    1045
#define IDC_SYSLINK2                    1046
#define IDC_STATIC_BMP1                 1047
#define IDC_STATIC_BMP2                 1048
#define IDC_STATIC_BMP3                 1049
#define IDC_STATIC_BMP4                 1050
#define IDC_BTN_UPDATELAMP1             1051
#define IDC_BTN_UPDATELAMP2             1052
#define IDC_BTN_UPDATELAMP3             1053
#define IDC_BTN_DFULAMP                 1054
#define IDC_LIST1                       1058
#define IDC_STATIC_INFO                 1059
#define IDC_STATIC_INFO1                1059
#define IDC_PROGRESS1                   1060
#define IDC_STATIC_WORKING              1060
#define IDC_STATIC_PROMPT               1061
#define IDC_STATIC_INFO2                1061
#define IDC_STATIC_INFO3                1062
#define IDC_STATIC_PROGRESS             1063
#define IDC_LIST2                       1064
#define IDC_LIST_FILE                   1064
#define IDC_STATIC_LENINFO1             1071
#define IDC_STATIC_LENINFO2             1072
#define IDC_STATIC_LENINFO3             1073
#define IDC_STATIC_LENINFO4             1074
#define IDC_STATIC_LENINFO5             1075
#define IDC_STATIC_LENINFO6             1076
#define IDC_BTN_FIXDEMO1                1080
#define IDC_BTN_FIXDEMO2                1081
#define IDC_BTN_FIXDEMO3                1082
#define IDC_BTN_FIXDEMO4                1083
#define IDM_REFRESHLISTBIN              32771
#define ID_POPMENU1_UPDATECUBE          32772
#define IDM_UPDATECUBE                  32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        154
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1065
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
