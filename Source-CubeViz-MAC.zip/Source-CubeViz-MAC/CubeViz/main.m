//
//  main.m
//  CubeViz
//
//  Created by luozhuang on 16-4-28.
//  Copyright (c) 2016年 CubeTube. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
