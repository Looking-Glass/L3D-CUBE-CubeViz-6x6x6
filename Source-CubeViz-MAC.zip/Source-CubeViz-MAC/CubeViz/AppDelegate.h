//
//  AppDelegate.h
//  CubeViz
//
//  Created by luozhuang on 16-4-28.
//  Copyright (c) 2016年 CubeTube. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
