//
//  ADScroller.h
//  AppDraft
//
//  Created by Leks on 13-9-19.
//  Copyright (c) 2013年 Leks Zhang. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ADScroller : NSScroller

@end
