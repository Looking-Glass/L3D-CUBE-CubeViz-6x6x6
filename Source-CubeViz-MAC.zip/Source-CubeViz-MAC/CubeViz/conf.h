//
//  conf.h
//  testTTY
//
//  Created by qiang on 16/3/31.
//  Copyright © 2016年 Qiangtech. All rights reserved.
//

#ifndef conf_h
#define conf_h

#include <stdio.h>

void myProcess();
void myProcess2(char *devName);
void myProcess3(char *devName);
    
#endif /* conf_h */
