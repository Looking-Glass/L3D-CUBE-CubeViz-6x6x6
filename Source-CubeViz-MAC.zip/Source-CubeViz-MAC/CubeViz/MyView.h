//
//  MyView.h
//  CubetubeTool
//
//  Created by qiang on 16/4/8.
//  Copyright © 2016年 Cubetube. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MyView : NSView

@property (nonatomic,strong) NSColor *backgoundColor;

@end
